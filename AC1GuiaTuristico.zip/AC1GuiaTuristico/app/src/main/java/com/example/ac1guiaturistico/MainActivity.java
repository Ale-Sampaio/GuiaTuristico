package com.example.ac1guiaturistico;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSaibaMais1 = findViewById(R.id.btnSaibaMais1);
        Button btnSaibaMais2 = findViewById(R.id.btnSaibaMais2);
        Button btnSaibaMais3 = findViewById(R.id.btnSaibaMais3);

        btnSaibaMais1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("nome", "Ronaldo Academy");
            intent.putExtra("descricao", "Academia de Futebol do Ronaldo.");
            intent.putExtra("telefone", "123456789");
            intent.putExtra("site", "https://r9sorocaba.academy/");
            intent.putExtra("mapa", "geo:0,0?q=Rua+antonio+aparecido+ferraz+1480");


            int[] images = {R.drawable.ronaldo, R.drawable.ronaldo2, R.drawable.ronaldo3};
            intent.putExtra("images", images);
            startActivity(intent);
        });

        btnSaibaMais2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("nome", "SmartFit");
            intent.putExtra("descricao", "Academia SmartFit.");
            intent.putExtra("telefone", "987654321");
            intent.putExtra("site", "https://www.smartfit.com.br/academias/shopping-cidade-sorocaba");
            intent.putExtra("mapa", "geo:0,0?q=Avenida+itavuvu+3080");


            int[] images = {R.drawable.ghimper1, R.drawable.ghimper2, R.drawable.ghimper3};
            intent.putExtra("images", images);
            startActivity(intent);
        });

        btnSaibaMais3.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("nome", "FourPlay");
            intent.putExtra("descricao", "Academia FourPlay");
            intent.putExtra("telefone", "1122334455");
            intent.putExtra("site", "https://fourplaysports.com.br/");
            intent.putExtra("mapa", "geo:0,0?q=Avenida+victor+andrew+880+zona+industrial");


            int[] images = {R.drawable.fourplay, R.drawable.fourplay2, R.drawable.fourplay3};
            intent.putExtra("images", images);
            startActivity(intent);
        });
    }
}
