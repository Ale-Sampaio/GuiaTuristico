package com.example.ac1guiaturistico;

public class Local {
    private String nome;
    private int imagemResId;
    private String descricao;
    private String telefone;
    private String site;
    private String mapaUri;

    public Local() {
    }

    public Local(String nome, int imagemResId, String descricao, String telefone, String site, String mapaUri) {
        this.nome = nome;
        this.imagemResId = imagemResId;
        this.descricao = descricao;
        this.telefone = telefone;
        this.site = site;
        this.mapaUri = mapaUri;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getImagemResId() {
        return imagemResId;
    }

    public void setImagemResId(int imagemResId) {
        this.imagemResId = imagemResId;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getMapaUri() {
        return mapaUri;
    }

    public void setMapaUri(String mapaUri) {
        this.mapaUri = mapaUri;
    }
}
