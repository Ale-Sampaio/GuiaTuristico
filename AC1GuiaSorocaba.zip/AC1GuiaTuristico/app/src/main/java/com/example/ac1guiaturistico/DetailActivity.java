package com.example.ac1guiaturistico;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private int currentImageIndex = 0;
    private int[] images;
    private ImageView imagemAtual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        Intent intent = getIntent();
        String nome = intent.getStringExtra("nome");
        String descricao = intent.getStringExtra("descricao");
        String telefone = intent.getStringExtra("telefone");
        String site = intent.getStringExtra("site");
        String mapa = intent.getStringExtra("mapa");


        images = intent.getIntArrayExtra("images");


        TextView titulo = findViewById(R.id.titulo);
        titulo.setText(nome);


        TextView descricaoDetalhe = findViewById(R.id.descricaoDetalhe);
        descricaoDetalhe.setText(descricao);

        imagemAtual = findViewById(R.id.imagemAtual);
        imagemAtual.setImageResource(images[currentImageIndex]);


        Button btnTelefone = findViewById(R.id.btnTelefone);
        btnTelefone.setOnClickListener(v -> {
            Intent intentTel = new Intent(Intent.ACTION_DIAL);
            intentTel.setData(Uri.parse("tel:" + telefone));
            startActivity(intentTel);
        });


        Button btnSite = findViewById(R.id.btnSite);
        btnSite.setOnClickListener(v -> {
            Intent intentSite = new Intent(Intent.ACTION_VIEW);
            intentSite.setData(Uri.parse(site));
            startActivity(intentSite);
        });


        Button btnMapa = findViewById(R.id.btnMapa);
        btnMapa.setOnClickListener(v -> {
            Intent intentMapa = new Intent(Intent.ACTION_VIEW);
            intentMapa.setData(Uri.parse(mapa));
            startActivity(intentMapa);
        });


        Button btnAnterior = findViewById(R.id.btnAnterior);
        btnAnterior.setOnClickListener(v -> {
            currentImageIndex--;
            if (currentImageIndex < 0) {
                currentImageIndex = images.length - 1;
            }
            imagemAtual.setImageResource(images[currentImageIndex]);
        });


        Button btnProximo = findViewById(R.id.btnProximo);
        btnProximo.setOnClickListener(v -> {
            currentImageIndex++;
            if (currentImageIndex >= images.length) {
                currentImageIndex = 0;
            }
            imagemAtual.setImageResource(images[currentImageIndex]);
        });
    }
}
